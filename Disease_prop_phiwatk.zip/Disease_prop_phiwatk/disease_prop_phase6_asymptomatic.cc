#include <iostream>
#include <string>
#include <vector>

using std::string;
using std::to_string;
using std::vector;
using std::cout;
using std::endl;

class Person {
	public:
		int sickday = 14;
		int state = 0;
		bool symptom_present = true; //default: the sick shows symptoms
		int symptom_onset = 5; //when symptoms start showing up 
		string sickstatement;
		float asymp_frac = 0.2; //20% of people infected with COVID are asymptomatic 

		int get_state() {
			return state;
		}
		
		string status_string() {
			// Return person's state as a string using Switch statement
			switch(state) {
				case 0 : 
					return "susceptible";
					break;
				case -1 :
					return "recovered";
					break;
				case -2 :
					return "vaccinated";
					break;
				default :
					if (symptom_present == true) {
						sickstatement = "sick (" + to_string(state) + " to go)";
					}
					else {
						sickstatement = "asymptomatic (" + to_string(state) + " to go)";
					}
					
					return sickstatement;
					break;
				}
		}
		
		void is_asymptomatic(int symptom_onset, float asymp_frac) {
			if (get_state() > (sickday - symptom_onset)) { 
				symptom_present = false; //symptom doesn't show up before symptom_onset day
			}
			else {
				float symptom_luck = (float) rand()/(float)RAND_MAX;

				if (symptom_luck < (1-asymp_frac)) {
					symptom_present = true; // 80% of the infected develop symptoms of COVID-19
				}
				else {
					symptom_present = false;
				}
			}
		}	

		void update() { 
			if (is_stable() == false) {
			// Next day, the sick person has one less sick day left
				state = state - 1;

				if (state == 0) {
					state = -1; //recovered
				}
			}
		}

		bool is_stable() {
			if (state > 0) {
				// Person is sick
				return false;
			}
			else {
				// Person is recovered
				return true;
			}

		}
		
		void infect(int sickday, int symptom_onset, float asymp_frac) {
			if (state==0) {
				state = sickday;
				is_asymptomatic(symptom_onset, asymp_frac);
			};
		}
	
		void vaccinate() {
			if (state==0) {
				state = -2;
			};
		}

};

class Population {
	public:
		int myPopsize = 10;
		int mySickday;
		int symptom_start;
		vector<Person> myPop;
		vector<int> count;		
		float transfer_prob;
		float bad_luck;
		int interaction;
		int max_interaction = 40; //for susceptible and asymptomatic people
		int limited_interaction = 5; //for sick people showing symptoms
		float percent_vaccine;
		float asymptomatic_fraction = 0.2;

		Population(int popsize, int sickday, int interact_max, int interact_limited, int symptomonset) {
			myPopsize = popsize;
			mySickday = sickday;
			max_interaction = interact_max;
			limited_interaction = interact_limited;
			symptom_start = symptomonset;

			// Add a variable of class Person to the vector myPop
			for (int i = 0; i < myPopsize; i++) {
				Person myPerson;
				myPop.push_back(myPerson);
				count.push_back(i);
			} 
		}
		
		void set_asymp_frac(float asymptomatic_frac) {
			asymptomatic_fraction = asymptomatic_frac;
		}

		void set_probability_of_transfer(float probability) {
			transfer_prob = probability;
		}
				
		void random_infection() {
			// Randomly infecting one person in myPop
			int infected_person = rand() % myPopsize;
			myPop.at(infected_person).infect(mySickday,symptom_start,asymptomatic_fraction);		
		}

		int count_infected() {
			int j = 0;

			// Count how many people are infected/sick in myPop
			for (auto i : count) {
				if (myPop.at(i).is_stable()) {}
				else {
					j = j + 1;
				}
			}
 
			return j;		
		}

		// Update + disease spread
		void update() {
			int num_sick = count_infected();
			for (auto i : count) {
			
				//Assign interaction number dpending on the asymptomatic status
				//A person is asymptomic up to symptom_onset date; some don't show symptoms past that date
				if (myPop[i].symptom_present == false) {
						//Asymptomatic  people interact with more people
						interaction = rand() % max_interaction + 1;
					}
					else {
						//those with symptoms interact with less people
						interaction = rand() % limited_interaction + 1;
					}

				myPop.at(i).update();
			}
		
		// Each sick person can infect another random person (with up to max_interaction)
			if (max_interaction == 0) {} //if no interaction, there's no spread of disease
			else {
				for (int j = 0; j < num_sick; j++) {

				
					for (int k = 0; k < interaction; k++) {
						bad_luck = (float) rand()/(float)RAND_MAX;
						if (bad_luck > transfer_prob) {} //lucky, nothing happens
						else { //unlucky, one rand person infected if susceptible
							random_infection();
						}
					}
				}
			}
		}

		void vaccinate(float percent_vaccine) {
			int num_vaccine = percent_vaccine*myPopsize;
			// cout << "Number of vaccinated = " << num_vaccine << endl;

			for (int k = 0; k < num_vaccine; k++) {
				int vaccinated_person = rand() % myPopsize;
				myPop.at(vaccinated_person).vaccinate();
			}		
		}	

};

int main() {
	srand((unsigned)time(0));
	
	int pop_size = 40000;
	int infection_period = 14; //COVID-19 period
	int symptomonset = 5; //symptoms usually show up after 5 days
	int maxinteraction = 10;
	int limitedinteraction = 5;
	float spread_prob = 0.1;
	float percent_vaccinated = 0;
	//float asymptomatic_fraction = 0.2; //20% of people infected with COVID-19 is asymptomatic
	
	
	cout << "Population size: " << pop_size << endl;
	cout << "Infection period: " << infection_period << " (Symptom onset: " << symptomonset << ", Spread prob: " << spread_prob << ")" << endl;
	cout << "Limited interaction: " << limitedinteraction << " Maximum interaction: " << maxinteraction << endl;
	cout << endl;

	cout << "Asymp_frac," << "Num_day," << "Num_sick," << endl;
	// asymp_frac = 1 is synonymous to no social distancing
	// asymp_frac = 0 is synonymous to complete social distancing, limited interaction to 5 people
	for (float asymp_frac = 0; asymp_frac < 1.05; asymp_frac = asymp_frac + 0.05) {
		Population A(pop_size,infection_period,maxinteraction,limitedinteraction, symptomonset);
		A.set_asymp_frac(asymp_frac);
		A.random_infection();
		A.set_probability_of_transfer(spread_prob);
		A.vaccinate(percent_vaccinated);	
	
		int step = 1;
		for ( ; ; step++) {
			//cout << "On day " << step << " #sick: " << A.count_infected() << endl;
			// cout << step << " , " << A.count_infected() << endl;

			A.update();

			// When #sick = 0, our simulation is done. (next day after update)
			if (A.count_infected() == 0) {
				step = step + 1;
				// cout << step << " , " << A.count_infected() << " , " << asymp_frac << endl;
				//cout << endl;
				break;
			}
		}
		
		int total_sick = 0;
		for (auto i : A.count) {
			if (A.myPop[i].get_state() == -1) {
				total_sick = total_sick + 1;
			}
		}
		
		cout << asymp_frac << " , " << step << " , " << total_sick << endl;
	}

	return 0;

}	
