#include <iostream>
#include <string>
#include <vector>

using std::string;
using std::to_string;
using std::vector;
using std::cout;
using std::endl;

class Person {
	public:
		int sickday;
		int state = 0;

		int get_state() {
			return state;
		}

		string status_string() {
			// Return person's state as a string using Switch statement
			switch(state) {
				case 0 : 
					return "susceptible";
					break;
				case -1 :
					return "recovered";
					break;
				case -2 :
					return "vaccinated";
					break;
				default :
					string sickstatement = "sick (" 
						+ to_string(state) + " to go)";
					return sickstatement;
					break;
				}
		}

		void update() { 
			if (is_stable() == false) {
			// Next day, the sick person has one less sick day left
				state = state - 1;

				if (state == 0) {
					state = -1; //recovered
				}
			}
		}

		bool is_stable() {
			if (state > 0) {
				// Person is sick
				return false;
			}
			else {
				// Person is recovered
				return true;
			}

		}
		
		void infect(int sickday) {
			if (state==0) {
				state = sickday;
			};
		}
	
		void vaccinate() {
			if (state==0) {
				state = -2;
			};
		}

};  // End class Person

class Population {
	public:
		int myPopsize = 10;
		int mySickday;
		vector<Person> myPop;
		vector<int> count;		
		float transfer_prob;
		float bad_luck;
		int max_interaction = 6; 
		float percent_vaccinate;
		int num_vaccinate;

		Population(int popsize, int sickday, int interact) {
			myPopsize = popsize;
			mySickday = sickday;
			max_interaction = interact;
	/*		
			cout << "Population size: " << myPopsize << endl;
			cout << "Infection period: " << mySickday << endl;
			cout << "Maximum interaction: " << max_interaction << endl;
	*/	
			// Add a variable of class Person to the vector myPop
			for (int i = 0; i < myPopsize; i++) {
				Person myPerson;
				myPop.push_back(myPerson);
				count.push_back(i);
			} 
		}
		
		void set_probability_of_transfer(float probability) {
			transfer_prob = probability;
		}
				
		void random_infection() {
			// Randomly infecting one person in myPop
			int infected_person = rand() % myPopsize;
			myPop.at(infected_person).infect(mySickday);		
		}

		int count_infected() {
			int j = 0;

			// Count how many people are infected/sick in myPop
			for (auto i : count) {
				if (myPop.at(i).is_stable()) {}
				else {
					j = j + 1;
				}
			}
			return j;		
		}
		
		int count_susceptible() {
			int j = 0;

			// Count how many people are susceptible in myPop
			for (auto i : count) {
				if (myPop.at(i).get_state()==0) {
					j = j + 1;
				}
			}
			return j;		
		}

		// Update + disease spread
		void update() {
			int num_sick = count_infected();
			for (auto i : count) {
				myPop.at(i).update();
			}
		// Each sick person can infect another random person (with up to max_interaction)
			if (max_interaction == 0) {} //if no interaction, there's no spread of disease
			else {
				for (int j = 0; j < num_sick; j++) {
					int interaction = rand() % max_interaction + 1;
				
					for (int k = 0; k < interaction; k++) {
						bad_luck = (float) rand()/(float)RAND_MAX;
						if (bad_luck > transfer_prob) {} //lucky, nothing happens
						else { //unlucky, one rand person infected if susceptible
							random_infection();
						}
					}
				}
			}
		}

		void vaccinate(float percent_vaccinate) {
			num_vaccinate = percent_vaccinate*myPopsize;
			//cout << "Number of vaccinated = " << num_vaccinate << " (" << percent_vaccinate*100 << "%)" << endl;
			int k = 0;

			while (k < num_vaccinate) {
				int vaccinated_person = rand() % myPopsize;
				
				// Skip the person who's already been vaccinated
				if(myPop.at(vaccinated_person).get_state() == -2) {}
				else {
					myPop.at(vaccinated_person).vaccinate();
					k = k + 1;
				}
			}		
		}	

}; // End class Population

int main() {
	srand((unsigned)time(0));
	
	int pop_size = 40000;
	int infection_period = 5;
	//int maxinteraction = 40;
	float spread_prob = 0.1;
	float percent_vaccinated = 0; //Assume no vaccination

	cout << "Population size: " << pop_size << endl;	
	cout << "Infection period: " << infection_period << endl;
	// cout << "Maximum interaction: " << maxinteraction << endl;
	cout << endl;

	cout << "Num_interaction ," << "Num_day, " << "Num_transmission" << endl;
	
	for (int maxinteraction = 0; maxinteraction < 41; maxinteraction = maxinteraction + 1) {
		
		Population A(pop_size,infection_period,maxinteraction);
		A.random_infection();
		A.set_probability_of_transfer(spread_prob);
		A.vaccinate(percent_vaccinated);

		int step = 1;
		for ( ; ; step++) {
		// cout << "On day " << step << " #sick: " << A.count_infected() << endl;
		// Store the daily number of infected people in a vector
			vector<int> num_infection;
			num_infection.push_back(A.count_infected());
		
			A.update();

		// When #sick = 0, our simulation is done. (next day after update)
			if (A.count_infected() == 0) {
				step = step + 1;
				num_infection.push_back(A.count_infected());
		//	cout << "On day " << step << " #sick: " << A.count_infected() << endl;
				break;
			}
		}
		
		int total_sick = 0;
		for (auto i : A.count) {
			if (A.myPop[i].get_state() == -1) {
				total_sick = total_sick + 1;
			}
		}
		float transmission = float(total_sick)/A.myPopsize;
	
		cout << maxinteraction << " , " << step << " , " << total_sick << endl;
/*	
		cout << "Number of day the disease runs in population: " << step << endl;
		cout << "Number of people were not sick and did not get vaccinated: " << A.count_susceptible() << endl; 
		cout << "Number of people who were infected: " << total_sick << endl;
		cout << "Percent transmission: " << transmission*100 << "%" << endl;
		cout << endl;
*/

	} //End for loop for percent_vaccinated

	return 0;

} // End main program	
